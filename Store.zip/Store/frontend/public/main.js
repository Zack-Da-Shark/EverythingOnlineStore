let unit1 = document.getElementById("unit1"); // product name
let unit4 = document.getElementById("unit4"); // product name
let unit1price = document.getElementById("unit1price"); // product price
let unit4price = document.getElementById("unit4price"); // product price
let unit1stock = document.getElementById("unit1stock"); // stock indicator for unit1

console.log("AM AWAKE"); // Debugging line to check if the script is running

fetch('http://localhost:3000/products')
  .then(res => res.json())
  .then(products => {
    console.log(products); // See what's returned
    const milk = products.find(p => p.name === "Creamers Full Fat Milk");
    if (milk) {
      unit4.textContent = milk.name;
      unit4price.textContent = `$${milk.price.toFixed(2)}`;
      console.log(`Milk price set to: $${milk.price.toFixed(2)}`);
    } else {
      console.log("Milk product not found!");
    }
  });

  fetch('http://localhost:3000/products')
  .then(res => res.json())
  .then(products => {
    console.log(products); // See what's returned
    const fan = products.find(p => p.name === "Techy Blue Desk Fan");
    if (fan) {
      unit1.textContent = fan.name;
      unit1price.textContent = `$${fan.price.toFixed(2)}`;
      if( fan.units > 0) {
        unit1stock.textContent = "In Stock";
      }
      else {
        unit1stock.textContent = "Out of Stock";
      }
      console.log(`Fan price set to: $${fan.price.toFixed(2)}`);
    } else {
      console.log("Fan product not found!");
    }
  });